const TTS_VOICES = {
  xiaochun: 'longxiaochun',
  xiaoxia: 'longxiaoxia',
  xiaoyue: 'longyue',
  laotie: 'longlaotie',
  chengge: 'longcheng',
};

function toDashScopeMsg(msg) {
  const role = msg.role;
  if (typeof msg.content === 'string') return { role, content: [{ text: msg.content }] };
  if (Array.isArray(msg.content)) {
    return {
      role,
      content: msg.content.map(p => {
        if (p.type === 'text') return { text: p.text };
        if (p.type === 'image_url') return { image: p.image_url.url };
        return p;
      })
    };
  }
  return { role, content: [{ text: String(msg.content) }] };
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };
}

async function handleChat(body) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) return { statusCode: 500, body: JSON.stringify({ error: 'API key not configured' }) };
  const { messages, temperature, max_tokens } = JSON.parse(body || '{}');
  const dashMessages = messages.map(toDashScopeMsg);
  const res = await fetch(
    'https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation',
    {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'qwen3.5-omni-plus',
        input: { messages: dashMessages },
        parameters: { temperature: temperature || 0.7, max_tokens: max_tokens || 1024, result_format: 'message' }
      })
    }
  );
  if (!res.ok) {
    const err = await res.text();
    return { statusCode: res.status, body: JSON.stringify({ error: err }) };
  }
  const data = await res.json();
  const output = data.output;
  let text = '';
  if (output.choices && output.choices[0]) {
    const msg = output.choices[0].message;
    text = Array.isArray(msg.content)
      ? msg.content.filter(p => p.text).map(p => p.text).join('')
      : (msg.content || '');
  } else if (output.text) {
    text = output.text;
  }
  return { statusCode: 200, body: JSON.stringify({ choices: [{ message: { role: 'assistant', content: text } }] }) };
}

async function handleTTS(body) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) return { statusCode: 500, body: JSON.stringify({ error: 'API key not configured' }) };
  const { text, voice } = JSON.parse(body || '{}');
  const modelVoice = TTS_VOICES[voice] || 'longxiaochun';
  const res = await fetch(
    'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-to-speech/generation',
    {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'qwen-tts',
        input: { text: (text || '').slice(0, 500) },
        parameters: { voice: modelVoice, format: 'mp3', sample_rate: 16000 }
      })
    }
  );
  if (!res.ok) {
    const err = await res.text();
    return { statusCode: res.status, body: JSON.stringify({ error: err }) };
  }
  const data = await res.json();
  const audioBase64 = data.output?.audio?.data || data.output?.audio_url;
  if (!audioBase64) return { statusCode: 500, body: JSON.stringify({ error: 'No audio data' }) };
  return { statusCode: 200, body: JSON.stringify({ audio: audioBase64 }) };
}

exports.handler = async (event, context, callback) => {
  const headers = corsHeaders();
  const method = event.method || event.httpMethod || 'GET';
  const path = event.path || event.rawPath || '/';
  const body = event.body || '';

  if (method === 'OPTIONS') {
    callback(null, { statusCode: 204, headers, body: '' });
    return;
  }

  try {
    let result;
    if (path === '/api/chat' && method === 'POST') {
      result = await handleChat(body);
    } else if (path === '/api/tts' && method === 'POST') {
      result = await handleTTS(body);
    } else {
      result = { statusCode: 404, body: JSON.stringify({ error: 'Not found' }) };
    }
    result.headers = { ...headers, ...(result.headers || {}) };
    callback(null, result);
  } catch (error) {
    callback(null, {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message }),
    });
  }
};